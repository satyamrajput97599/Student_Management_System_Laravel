-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2024 at 06:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studentdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `id` int(100) NOT NULL,
  `sid` int(50) NOT NULL,
  `dt` varchar(50) NOT NULL,
  `st` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`id`, `sid`, `dt`, `st`) VALUES
(6, 4, '05-04-24 06:08:41', 'Present'),
(7, 9, '05-04-24 06:08:41', 'absent'),
(8, 21, '05-04-24 06:08:41', 'absent'),
(9, 33, '05-04-24 06:08:41', 'Present'),
(10, 40, '05-04-24 06:08:41', 'late'),
(11, 3, '05-04-24 06:09:28', 'Present'),
(12, 7, '05-04-24 06:09:28', 'absent'),
(13, 14, '05-04-24 06:09:28', 'Present'),
(14, 15, '05-04-24 06:09:28', 'absent'),
(15, 8, '05-04-24 07:14:12', 'absent'),
(16, 38, '05-04-24 07:14:12', 'late'),
(17, 39, '05-04-24 07:14:12', 'Present'),
(18, 12, '08-04-24 03:03:52', 'Present'),
(19, 12, '08-04-24 03:04:30', 'Present'),
(20, 8, '08-04-24 07:20:05', 'Present'),
(21, 10, '08-04-24 07:20:05', 'Present'),
(22, 13, '08-04-24 07:20:05', 'Present'),
(23, 20, '08-04-24 07:20:05', 'Present'),
(24, 28, '08-04-24 07:20:05', 'Present'),
(25, 8, '08-04-24 07:20:11', 'Present'),
(26, 10, '08-04-24 07:20:11', 'Present'),
(27, 13, '08-04-24 07:20:11', 'Present'),
(28, 20, '08-04-24 07:20:11', 'Present'),
(29, 28, '08-04-24 07:20:11', 'Present'),
(30, 12, '08-04-24 07:20:33', 'Present'),
(31, 41, '08-04-24 07:20:34', 'Present'),
(32, 12, '08-04-24 07:20:48', 'absent'),
(33, 35, '08-04-24 07:20:48', 'late'),
(34, 44, '25-04-24 05:59:35', 'absent'),
(35, 12, '25-04-24 06:00:12', 'Present');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id` int(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `level` int(50) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id`, `course`, `level`, `section`) VALUES
(1, 'python', 2, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course`, `description`) VALUES
(9, 'javacript', 'iugu');

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`, `email`, `contact`, `address`, `password`, `subject`) VALUES
(0, 'amrita rawat', 'amrita@gmail.com', 9087777, 'ijgggg', '2120', 'subject1'),
(6777, 'khusbu', 'khusbu@gmail.com', 9087777, 'ijgggg', '5691', 'subject1'),
(55556, 'aman rawat', 'aman@gmail.com', 89776544, 'premnagar', '3892', 'subject3'),
(677788, 'Anjali butola', 'anjalibutola@gmail.com', 9087777, 'bhauwala', '4148', 'subject2');

-- --------------------------------------------------------

--
-- Table structure for table `second`
--

CREATE TABLE `second` (
  `id` int(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `faculty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `second`
--

INSERT INTO `second` (`id`, `class`, `subject`, `faculty`) VALUES
(1, 'python 1-A', 'subject 2', 'anjali'),
(2, 'java 2-B', 'subject 2', 'amrita'),
(3, 'java 2-B', 'subject 2', 'amrita'),
(7, 'python 1-A', 'subject 1', 'anjali');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `pid` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `course`, `subject`, `pid`) VALUES
(66666, 'anjali', 'java 2-B', 'subject2', 2),
(8888, 'aman', 'react 3-c', 'subject2', 3),
(99099, 'amrita', 'python 1-A', 'subject3', 4),
(76699, 'tanu', 'react 3-c', 'subject1', 8),
(7644, 'vaishali', 'react 3-c', 'subject3', 9),
(3344, 'pratiksha', 'java 2-B', 'subject1', 10),
(3322, 'sharmila', 'python 1-A', 'subject2', 11),
(2211, 'kajal', 'react 3-c', 'subject4', 12),
(9900, 'lucky', 'java 2-B', 'subject1', 13),
(77666, 'kusum', 'java 2-B', 'subject2', 14),
(77, 'vishal', 'java 2-B', 'subject2', 15),
(9966, 'deepali', 'java 2-B', 'subject2', 16),
(9966, 'deepali', 'java 2-B', 'subject2', 17),
(5454, 'divya', 'java 2-B', 'subject2', 18),
(8898, 'shivam', 'java 2-B', 'subject2', 19),
(5566, 'shivani', 'python 1-A', 'subject1', 20),
(3343, 'kalash', 'java 2-B', 'subject3', 21),
(9009, 'abhishek', 'java 2-B', 'subject2', 22),
(5576, 'abhilash', 'java 2-B', 'subject2', 23),
(7876, 'sachin', 'react 3-c', 'subject2', 24),
(3533, 'anchal', 'react 3-c', 'subject2', 25),
(2435, 'shad', 'java 2-B', 'subject2', 26),
(2422, 'rohan', 'react 3-c', 'subject2', 27),
(8666, 'ronika', 'java 2-B', 'subject1', 28),
(5252, 'avantika', 'java 2-B', 'subject2', 29),
(7656, 'anuradha', 'java 2-B', 'subject1', 30),
(2722, 'anand', 'react 3-c', 'subject2', 31),
(2322, 'golu', 'python 1-A', 'subject2', 32),
(1242, 'sakshi', 'python 1-A', 'subject3', 33),
(2626, 'santoshi', 'python 1-A', 'subject2', 34),
(7676, 'soni', 'python 1-A', 'subject4', 35),
(2622, 'poonam', 'java 2-B', 'subject2', 36),
(9078, 'vaidu', 'react 3-c', 'subject2', 37),
(989, 'rajni', 'java 2-B', 'subject1', 38),
(2321, 'gaurav', 'java 2-B', 'subject1', 39),
(928, 'shagun', 'react 3-c', 'subject3', 40),
(2718, 'tushar', 'java 2-B', 'subject4', 41),
(8722, 'suraj', 'java 2-B', 'subject2', 42),
(928, 'meenakshi', 'java 2-B', 'subject2', 43),
(9836, 'neelam', 'python 1-A', 'subject4', 44),
(2898, 'akku', 'react 3-c', 'subject2', 45),
(9822, 'abha', 'java 2-B', 'subject4', 46),
(192, 'guru', 'java 2-B', 'subject2', 47),
(9882, 'mayank', 'python 1-A', 'subject4', 48),
(393, 'naman', 'java 2-B', 'subject2', 49),
(2827, 'rohit', 'java 2-B', 'subject2', 50),
(2210, 'cheta', 'java 2-B', 'subject2', 51);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subject`, `description`) VALUES
(8, 'subject4', 'uihuygy'),
(13, 'subject2', 'jh'),
(16, 'subject1', 'hghfvfvfff'),
(17, 'subject3', 'jihhghygc');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `password` int(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`, `email`) VALUES
('anjali', 12345, 'anjali@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `second`
--
ALTER TABLE `second`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `second`
--
ALTER TABLE `second`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `pid` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
